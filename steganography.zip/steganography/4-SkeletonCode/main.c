/*
Author:Nanda P

Organisation:Emertxe

Date:30-05-2024

Description:Steganography is a technique used to hide information within a digital medium,such as image.It involves modifying the least significant bit of each data byte in the carrier medium to embed the hidden message.

The main objectives of the project:
1)Encoding secret data in the least bits of carrier file's pixels
2)Decoding secret data without altering the image.
 */




/*standard I/O library for file operations such as fread,fwrite,printf */
#include <stdio.h>
/*String manipulation functions like strlen,strcmp,strstr,strtok */
#include <string.h>
/* header for encoding functions, declarations specific to encoding process */
#include "encode.h"
/* header for type definitions*/
#include "types.h"
/*  header for common definitions */
#include "common.h"
/* header for decoding functions, declarations specific to encoding process */
#include "decode.h"

/*
Function:error_msg
Prints a usage error message to the console. This function is called 
whenever the command-line arguments do not meet the required criteria 
for either encoding or decoding operations.
 */


void error_msg()
{
    printf("Usage:For encoding -> ./a.out -e beautiful.bmp secret.txt output.bmp \n For decoding -> ./a.out -d output.bmp");
}

/*
   main function
   This function handles the command-line 
   arguments, determines the operation type (encoding or decoding), and performs the corresponding process.
   It performs the following steps:
   - Initializes the encoding and decoding structures.
   - Checks the type of operation based on the command-line arguments.
   - Executes encoding or decoding functions if the arguments are valid.
   -If the user does not pass -e or -d error message is displayed
 */


int main(int argc, char *argv[])
{


    if(argc>1)
    {


	EncodeInfo encInfo;
	Decode decInfo;

	int type= check_operation_type(argv);



	/* Encoding */

	if(type == e_encode)
	{
	    if(argc >=4 && argc <=5)
	    {
		printf("\n\t\t\t:::ENCODING OPERATION SELECTED.:::\n");

		if(read_and_validate_encode_args(argv,&encInfo) == e_success)
		{
		    printf("\n\t\t\t:::READ AND VALIDATION COMPLETED SUCCESSFULLY:::\n");
		}
		else
		{
		    printf("\nREAD AND VALIDATION FAILED\n");
		    return 0;
		}

		if(do_encoding(&encInfo) == e_success)
		{
		    printf("\n\t\t\t:::ENCODING DONE SUCCESSFULLY!:::\n");
		}

		else
		{
		    printf("\nENCODING FAILED!\n");
		    return 0;
		}

	    }

	    else
	    {
		printf("Error:Invalid arguments\n");
		printf("Usage error:For encoding -> ./a.out -e beautiful.bmp secret.txt output.bmp \n\t For decoding -> ./a.out -d output.bmp\n");

	    }
	}


	/* Decoding */

	else if(type == e_decode)
	{
	    if(argc >= 3 && argc <= 4)
	    {
		printf("\n\t\t\t:::DECODING OPERATION SELECTED:::\n");
		if(read_and_validate_decode_args(argv,&decInfo) == e_success)
		{
		    printf("\n\t\t\t:::READ AND VALIDATION DONE SUCCESSFULLY!:::\n");

		    if(do_decoding(&decInfo) == e_success)
		    {
			printf("\n\t\t\tDECODING DONE SUCCESSFULLY!:::\n");
		    }
		    else
		    {
			printf("\n\t\t\t\t\t\tDECODING FAILED!\n\n");
		    }
		}
		else
		{
		    printf("\n\t\t\t\tREAD AND VALIDATION FAILED!\n\n");
		}
	    }
	    else
	    {
		printf("Error:Invalid arguments\n");
		printf("Usage error:For encoding -> ./a.out -e beautiful.bmp secret.txt output.bmp \n\t For decoding -> ./a.out -d output.bmp\n");

	    }

	}




	else if(type == e_unsupported)
	{
	    printf("error: Unsupported operation type!\n");

	}

    }
    else
    {
	printf("Error:Invalid arguments\n");
	printf("Usage error:For encoding -> ./a.out -e beautiful.bmp secret.txt output.bmp \n\t For decoding -> ./a.out -d output.bmp\n");
    } 
    return 0;
}

/*
   Determines the type of operation to perform based on the command-line arguments.
 * This function checks the first argument to see if it matches the encoding ("-e")
 * or decoding ("-d") flag.
Returns:
 * - e_encode if the operation is encoding.
 * - e_decode if the operation is decoding.
 * - e_unsupported if the operation type is not recognized.
 */

OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1],"-e") == 0)
    {

	return e_encode;
    }
    else if(strcmp(argv[1],"-d") == 0)

    {
	return e_decode;
    }
    else
    {
	return e_unsupported;

    }
}

