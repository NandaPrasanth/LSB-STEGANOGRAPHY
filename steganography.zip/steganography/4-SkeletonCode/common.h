/*
Author:Nanda P
Organisation:Emertxe
Date:30-05-2024
Description:Steganography is a technique used to hide information within a digital medium,such as image.It involves modifying the least significant bit of each data byte in the carrier medium to embed the hidden message.
The main objectives of the project:
1)Encoding secret data in the least bits of carrier file's pixels 
2)Decoding secret data without altering the image. 
*/
#ifndef COMMON_H
#define COMMON_H

/* Magic string to identify whether stegged or not */
/* Magic string to identify whether a file is stegnographically encoded */
#define MAGIC_STRING "#*"

#endif
