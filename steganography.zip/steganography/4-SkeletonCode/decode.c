/*
Author:Nanda P

Organisation:Emertxe

Date:30-05-2024

Description:Steganography is a technique used to hide information within a digital medium,such as image.It involves modifying the least significant bit of each data byte in the carrier medium to store the hidden message.

The main objectives of the project:
1)Encoding secret data in the least bits of carrier file's pixels
2)Decoding secret data without altering the image.
*/

/*standard I/O library for file operations such as fread,fwrite,printf */
#include <stdio.h>
/*String manipulation functions like strlen,strcmp,strstr,strtok */
#include <string.h>
/* header for decoding functions, declarations specific to decoding process */
#include "decode.h"
/* header for type definitions*/
#include "types.h"
/*  header for common definitions */
#include "common.h"

/* header for encoding functions, declarations specific to decoding process */
#include "encode.h"


/* Function Definitions */



/* Function:read_and_validate_decode_args
   This function reads and validates the command line arguments for the decode operation.
   It checks the file extension of the source image and assigns the provided or default output file name.
   Returns:
     Status: e_success if the arguments are valid and assigned correctly, otherwise e_failure.
 */

Status read_and_validate_decode_args(char *argv[], Decode *decInfo)
{

    /* argv[2]-source image file 

    
      Check for file extension
      Store the file name with .bmp extension
     */

    if ( strstr(argv[2],".") == NULL )     
    {
        printf("\nerror: No file extension!\n");

        

        return e_failure;
    }

    else
    {
        if ((strcmp(strstr(argv[2],".bmp"), ".bmp")) == 0)
        {
            decInfo -> d_src_image_fname = argv[2];
        }

    }


    /* argv[3]-Secretfile name */

    if(argv[3] != NULL)
    {
        if ( strstr(argv[3], ".") == NULL )
        {
            decInfo -> secret_fname = argv[3];

        }

        else
        {
            decInfo -> secret_fname = strtok(argv[3],".");
        }
    }

    else
    {
        decInfo -> secret_fname = "Output";

        printf("\n\t\t\t:::INFO: Output File not mentioned.:::\n\t\t\t:::As default, creating a file named \"Output\" without extension.:::\n");

    }

    return e_success;

}


/*Function:do_decoding
   Perform the decoding 
   This function coordinates the decoding process by opening files, skipping headers, and decoding the embedded data.
    Returns:
    e_success if all decoding steps are successful, otherwise e_failure.
 */

Status do_decoding(Decode *decInfo)
{
    printf("\n\t\t\t:::INFO: Opening required files...\n");



    if (decode_open_files(decInfo) == e_success)
    {
        printf("\n\t\t\t:::FILE OPENED SUCCESSFULLY!\n");

    }

    else
    {
        printf("\nerror: FILE OPENING FAILED!\n");

        return e_failure;
    }


    if(skip_bmp_header(decInfo->d_fptr_src_image) == e_success)
    {
        printf("\n\t\t\t:::BMP HEADER SKIPPED!:::\n\t\t\t:::STARTED TO DECODE THE MAGIC STRING!:::\n");

    }

    else
    {
        printf("\nerror : OPERATION FAILED!\n");

        return e_failure;
    }


    if (decode_magic_string(decInfo) == e_success)
    {
        printf("\n\t\t\t:::MAGIC STRING DECODED SUCCESSFULLY!:::\n");

    }

    else
    {
        printf("\nMAGIG STRING DECODE FAILED!\n");

        return e_failure;
    }


    if(decode_secret_file_extn(decInfo) == e_success)
    {
        if (decode_secret_file_size(decInfo) == e_success )
        {
            printf("\n\t\t\t:::SECRET FILE SIZE DECODED SUCCESSFULLY!:::\n");

        }
    }

    else
    {
        printf("\nerror : DECODING SECRET FILE SIZE FAILED!\n");

        return e_failure;
    }


    if(decode_secret_file_data(decInfo) == e_success )
    {
        printf("\n\t\t\t:::SECRET FILE DATA DECODED SUCCESSFULLY!:::\n");

    }

    else
    {
        printf("\nDECODING SECRET FILE DATA FAILED!\n");

        return e_failure;
    }


    return e_success;
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file name.
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors */


/* Get File pointers for i/p and o/p files */


/* Function:decode_open_files
   This function opens the source image file for reading and sets the file pointer in the Decode structure.
    Returns:
     Status: e_success if the file is opened successfully, otherwise e_failure.
 */

Status decode_open_files(Decode *decInfo)
{
    printf("\n\t\t\t:::INFO: %s FILE OPENED.:::\n", decInfo -> d_src_image_fname);

    decInfo -> d_fptr_src_image = fopen(decInfo -> d_src_image_fname,"r");

    /* check if the file is opened successfully */

    if(decInfo -> d_fptr_src_image == NULL  )   
    {
        perror("fopen");

        fprintf(stderr,"ERROR:Unable to open file %s\n",decInfo -> d_src_image_fname );

        return e_failure;
    }


    return e_success;
}


/* Skip input image header data 
   Function:skip_bmp_header
   This function skips the header of the BMP image file by moving the file pointer 54 bytes ahead.
   Returns:
     Status: e_success after skipping the header.
 
 */

Status skip_bmp_header(FILE *d_fptr_src_image)
{
    fseek(d_fptr_src_image,54,SEEK_SET);  

    return e_success;
}


/* Decode Magic String
   Function:decode_magic_string
   This function decodes the magic string embedded in the image by reading the LSB of each byte.
   It compares the decoded string with the predefined MAGIC_STRING to verify the presence of hidden data.
   Returns:
     Status: e_success if the magic string is decoded and verified successfully, otherwise e_failure.
 */

Status decode_magic_string(Decode *decInfo)
{



    char temp[8];

    int i;

    int size_magic_string = strlen(MAGIC_STRING);

    char check_magic_string[size_magic_string + 1];

    for(i = 0 ; i < size_magic_string; i++)
    {
        fread(temp, 8, 1, decInfo -> d_fptr_src_image);

        check_magic_string[i] = decode_byte_from_lsb(temp);
    }


    check_magic_string[i]='\0';


    printf("\n\t\t\t:::DECODED MAGIC STRING IS : %s:::\n",check_magic_string);


    if(strcmp(check_magic_string,MAGIC_STRING) == 0)
    {
        printf("\n\t\t\t:::Magic String verification done!:::\n");

        return e_success;
    }

    else
    {
        return e_failure;
    }
}


/* Decode secret file extension 
   Function:decode_secret_file_extn
   This function decodes the extension of the secret file from the image.
   It reads the encoded extension size and then the extension itself, storing it in the Decode structure.
   Return:
     Status: e_success if the extension is decoded successfully, otherwise e_failure.
 
 */

Status decode_secret_file_extn(Decode *decInfo)
{
    printf("\n\t\t\t:::Decoding output file extension...:::\n");

    char temp_secret[32];

    int i;

    fread(temp_secret, 32, 1, decInfo -> d_fptr_src_image);

    int secret_extn_size = decode_size_from_lsb(temp_secret);

    char temp_secret_extn[secret_extn_size + 1];

    char temp[8];

    for (i = 0 ; i < secret_extn_size; i++)
    {
        fread(temp, 8, 1, decInfo -> d_fptr_src_image);

        temp_secret_extn[i] = decode_byte_from_lsb(temp);
    }

    temp_secret_extn[i] = '\0';


        printf("\n\t\t\t:::SECRET FILE EXTENSION DECODED SUCCESSFULLY!:::\n");

        printf("\n\t\t\t:::Secret File extension size = %d:::\n",secret_extn_size - 2);
 
        strcpy(decInfo ->secret_extn, decInfo-> secret_fname );

        strcat(decInfo -> secret_extn,temp_secret_extn);

        printf("\n\t\t\t\t:::Extension:%s Name:%s:::\n", decInfo -> secret_extn, decInfo -> secret_fname);
     
	return e_success;
}


/* Decode secret file size 
   Function:decode_secret_file_size
   This function decodes the size of the secret file from the image.
   It reads 32 bytes and extracts the size using LSB decoding.

   Returns:
     Status: e_success if the size is decoded successfully, otherwise e_failure.
 
 */

Status decode_secret_file_size(Decode *decInfo)
{
    char temp[32];

    fread(temp,1,32,decInfo->d_fptr_src_image);

    decInfo->secret_file_size = decode_size_from_lsb(temp);

    return e_success;
}


/* Decode secret file data
   Function:decode_secret_file_data
   This function decodes the secret file data embedded in the image.
   It reads 8 bytes at a time, decodes each byte, and writes the decoded byte to the output secret file.
   Returns:
     Status: e_success upon successful decoding of the secret file data, otherwise e_failure.
 
*/

Status decode_secret_file_data(Decode *decInfo)
{
    char secret_data[8];

    int i;

    char ch;

    decInfo -> fptr_secret = fopen(decInfo ->secret_extn ,"w");


    printf("\n\t\t\t:::The Secret file size is %ld:::\n",(decInfo->secret_file_size - 1));

    printf("\n\t\t\t:::The Secret file data is : ");

    for ( i = 0; i < (decInfo -> secret_file_size - 1); i++)
    {
        fread (secret_data, 1, 8, decInfo -> d_fptr_src_image);

        ch = decode_byte_from_lsb(secret_data);

        fwrite ( &ch ,1, 1, decInfo->fptr_secret);

        printf("%c",ch);
    }


    return e_success ;
}


/* Decode a byte from LSB of image data array 
   Function:decode_byte_from_lsb
   This function decodes a single byte from the LSBs of the provided data array.
   It reads the LSB from each of the 8 bytes in the array, constructs a byte, and returns it.
   Returns:
     char: Decoded byte.
 */

Status decode_byte_from_lsb(char *data)
{
    /*
     * Get the lsb from data[i]
     * Left shift towards msb since we've encoded from msb of character
     * Initialize a char variable with 0 to store the decoded bits for one character
     * Add the get bit to the ch
     */

    char ch = 0;       

    for(int i=0 ; i<8 ; i++)
    {
        ch = (ch | ((data[i] & (1)) << (7-i)));
    }


    return ch;
}


/*Decode size from LSB of image data array
  Function:decode_size_from_lsb
  This function decodes an integer size from the LSBs of the provided data array.
  It reads the LSB from each of the 32 bytes in the array, constructs the integer, and returns it  
  Returns:
     int: Decoded size.*/

Status decode_size_from_lsb(char *image_buffer)
{
    /*
     * Get the lsb from buffer[i]
     * Left shift towards msb since we've encoded from msb of character
     * Add the get bit to the ch
     */

    int size_extn = 0;

    for(int i = 0 ; i <32  ; i++)
    {
        size_extn = (size_extn | ((image_buffer[i] & (1)) << (31-i)));
    }


    return size_extn;
}
