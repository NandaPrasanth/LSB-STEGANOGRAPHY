/*
Author:Nanda P

Organisation:Emertxe

Date:30-05-2024

Description:Steganography is a technique used to hide information within a digital medium,such as image.It involves modifying the least significant bit of each data byte in the carrier medium to store the hidden message.

The main objectives of the project:
1)Encoding secret data in the least bits of carrier file's pixels
2)Decoding secret data without altering the image.
*/


/*standard I/O library for file operations such as fread,fwrite,printf */
#include <stdio.h>
/*String manipulation functions like strlen,strcmp,strstr,strtok */
#include <string.h>
/* header for encoding functions, declarations specific to encoding process */
#include "encode.h"
/* header for type definitions*/
#include "types.h"
/*  header for common definitions */
#include "common.h"


/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18 and height after that size is 4 bytes
 */

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;

    /* Seek to 18th byte */
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    //printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/*
   Function: open_files
   Opens the source image, secret, and stego image files.
   Inputs: Src Image file, Secret file and
   Stego Image file
   Output:Opens files.
   Return Value: e_success or e_failure, on file errors
 */

Status open_files(EncodeInfo *encInfo)
{
    /* Src Image file */
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    /* Do Error handling */
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    /* Secret file */
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    /* Do Error handling */
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    /* Stego Image file */
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    /*Do Error handling */
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    /* No failure return e_success*/
    return e_success;
}


/* READ AND VALIDATION OF ENCODE ARGS
   Description:
   Reads and validates the command line arguments for encoding.
   This function validates the file extensions of the source image, secret file, and stego image file. It ensures the correct 
   file types are provided and stores the file names in the EncodeInfo structure.


 */

Status read_and_validate_encode_args(char * argv[], EncodeInfo * encInfo)
{
    /*check argv[2]-Source image file*/

    if(strstr(argv[2],".") == NULL)
    {
        printf("\nerror: No image file extension!\n");

        

        return e_failure;
    }

    else
    {
        if(strcmp(strstr(argv[2],"."), ".bmp") == 0)
        {
            encInfo -> src_image_fname = argv[2];

            printf("\n\t\t\t:::Source image file name stored successfully!:::\n");
        }

        else
        {
            printf("\nerror: Invalid image file type\n");

            

            return e_failure;
        }
    }


    /* check argv[3]-Secret file */

    if(strstr(argv[3],".") == NULL)
    {
        printf("\nerror: No secret file extension!\n");

        

        return e_failure;
    }

    else
    {
        if(strcmp(strstr(argv[3],"."), ".txt") == 0)
        {
            encInfo -> secret_fname = argv[3];

            printf("\n\t\t\t:::Secret file name stored successfully!:::\n");
        }

        else
        {
            printf("\nerror: Invalid secret file type\n");

            

            return e_failure;
        }
    }


    /* check argv[4]-Stego image file */

    if(argv[4] == NULL)
    {
        encInfo -> stego_image_fname = "output.bmp";

        printf("\n\t\t\t:::File name set to default --->\"output.bmp\" :::");
    }

    else
        {
            if(strstr(argv[4],".") == NULL)
            {
                printf("\nerror: No image file extension!\n");

                

                return e_failure;
            }

            else
            {
                if(strcmp(strstr(argv[4],"."), ".bmp") == 0)
                {
                    encInfo -> stego_image_fname = argv[4];

                    printf("\n\t\t\t:::Stego image file name stored successfully!:::\n");
                }

                else
                {
                    printf("\nerror: Invalid stego image file type\n");

                    

                    return e_failure;
                }
            }

        }

    return e_success;
}


/*
   Function: do_encoding
   Performs the encoding process by hiding the secret file within the source image.
    encInfo: Pointer to the EncodeInfo structure containing file pointers and information.
    This function performs the encoding process by calling various helper functions to check 
    capacity, copy headers, and encode the secret data into the stego image.
 */

Status do_encoding(EncodeInfo *encInfo)
{

    /* check whether the file is opening properly or not */

    if(open_files(encInfo) == e_success)
    {
        printf("\n\t\t\t:::FILE OPENED SUCCESSFULLY!:::\n");
        
    }
    else
    {
        printf("\nerror: File opening failed!\n");

        return e_failure;
    }


    /* check for the source image file capacity */

    if(check_capacity(encInfo) == e_success)
    {
        printf("\n\t\t\t:::CHECK CAPACITY COMPLETED!:::\n");
        
    }
    else
    {
        printf("\nerror: Check capacity failed!\n");

        return e_failure;
    }


    /* copy bmp header from src image file to stego image file */

    if(copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
    {
        printf("\n\t\t\t:::COPYING BMP HEADER DONE SUCCESSFULLY!:::\n");
    }
    else
    {
        printf("\nerror: Copying bmp header failed!\n");

        return e_failure;
    }


    /* Encoding Magic string*/

    if(encode_magic_string(MAGIC_STRING, encInfo) == e_success)
    {
        printf("\n\t\t\t:::ENCODING MAGIC STRING DONE SUCCESSFULLY!:::\n");
    }
    else
    {
        printf("\nerror: Encoding Magic string failed!\n");

        return e_failure;
    }


    /*Encoding size of secret file extension*/


    strcpy(encInfo -> extn_secret_file, ".txt");
    if(encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file), encInfo) == e_success)
    {
        printf("\n\t\t\t:::ENCODING SECRET FILE EXTENSION SIZE DONE SUCCESSFULLY!:::\n");
    }
    else
    {
        printf("\nerror: Encoding secret file extension failed!\n");

        return e_failure;
    }


    /*Encoding extension of secret file*/

    if(encode_secret_file_extn(encInfo -> extn_secret_file, encInfo) == e_success)
    {
        printf("\n\t\t\t:::ENCODING SECRET FILE EXTENSION DONE SUCCESSFULLY!:::\n");
    }
    else
    {
        printf("\nerror: Encoding secret file extension failed!\n");

        return e_failure;
    }


    /*Encoding size of secret file*/

    if(encode_secret_file_size(encInfo -> size_secret_file, encInfo) == e_success)
    {
        printf("\n\t\t\t:::ENCODING SECRET FILE SIZE DONE SUCCESFULLY!:::\n");
    }
    else
    {
        printf("\nerror: Encoding secret file size failed!\n");

        return e_failure;
    }


    /*Encoding secret msg*/

    if(encode_secret_file_data(encInfo) == e_success)
    {
        printf("\n\t\t\t:::ENCODING SECRET FILE DATA DONE SUCCESSFULLY!:::\n");
    }
    else
    {
        printf("\nerror: Encoding secret file data failed!\n");

        return e_failure;
    }


    /*Copying remaining data from source image to the stego image after encoding done*/

    if(copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
    {
        printf("\n\t\t\t:::REMAINING SOURCE IMAGE DATA COPIED SUCCESSFULLY TO THE OUTPUT IMAGE FILE!:::\n");
    }
    else
    {
        printf("\nerror: copying remaining data from source image file failed!\n");

        return e_failure;
    }



    return e_success;
}


/*Function: Get file size
 This function calculates the size of a given file by moving the file  pointer to the end of the file and using ftell to get the size in bytes.
 returns: The size of the file in bytes.
 */

uint get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);

    return ftell(fptr);
}


/* Function: Check capacity
   This function checks whether the source image has enough capacity to  hold the encoded secret data. It calculates the image capacity and the size of the secret file, and compares it with the required capacity needed for encoding.
   returns: e_success if the image has enough capacity,otherwise e_failure.
 */

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);

    encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);



    if(encInfo -> image_capacity > (54 + strlen(MAGIC_STRING) + 32 + 32 + 32 + (encInfo -> size_secret_file) * 8))
    {
        printf("\n\t\t\t:::BMP FILE WILL FIT.\n");

        return e_success;
    }

    else
    {
        return e_failure;
    }
}


/* Function: copy_bmp_header
 
   This function copies the BMP header from the source image file to the stego image file. The BMP header is assumed to be 54 bytes long.
 
   fptr_src_image: A pointer to the source image file.
   fptr_stego_image: A pointer to the stego image file.
 
   returns: e_success if the BMP header is copied successfully.
  */

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_stego_image)
{
    rewind(fptr_src_image);

    char arr[54];

    fread(arr,54,1,fptr_src_image);

    fwrite(arr,54,1,fptr_stego_image);

    return e_success;
}

/*
   Function: Encode Magic String
   This function encodes a magic string into the source image by reading 8 bytes at a time, encoding each byte of the magic string into the    least significant bit LSB of each byte in the 8-byte block, and then writing the modified 8-byte block to the stego image.
   returns: e_success if the magic string is encoded successfully.
 
 */


Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char buffer[8];


    for(int i=0; i<strlen(magic_string); i++)
    {
        fread(buffer, 1, 8, encInfo -> fptr_src_image);

        encode_byte_to_lsb(magic_string[i], buffer);

        fwrite(buffer, 1, 8, encInfo -> fptr_stego_image);
    }

    return e_success;
}



/* Function: encode_byte_to_lsb
   This function encodes a byte of data into the  LSB of each byte in an 8-byte image buffer.
   It clears the LSB of each byte in the image buffer and then sets it to the corresponding bit from the data byte.
   returns: e_success if the byte is encoded successfully.

 */

Status encode_byte_to_lsb(char data, char *image_buffer)
{

    /*
     * Clear the LSB of the source image file byte
     * Get a bit from the data (character)
     * Add the get bit in the place of cleared bit
     */

    for(int i=0; i<8; i++)
    {
        image_buffer[i] = (image_buffer[i] & 0xfe) | ((data & (1 << 7 - i)) >> 7-i);
    }

    return e_success;
}


/* Function: encode_size_to_lsb
   Encode a size into LSB of source image data array
   byte in the image buffer and then sets it to the corresponding bit from the size.
   size: The size to be encoded.
   image_buffer: A 32-byte buffer of image data in which the size will be encoded.
 
 returns: e_success if the size is encoded successfully.
  */

Status encode_size_to_lsb(long size, char *image_buffer)
{

    /*
     * Clear the LSB of the source image file byte
     * Get a bit from the size (integer)
     * Add the get bit in the place of cleared bit
     */

    for(int i=0; i<32; i++)
    {
        image_buffer[i] = (image_buffer[i] & 0xfe) | ((size & (1 << 31 - i)) >> 31 - i);
    }

    return e_success;
}


/* Function: encode_secret_file_extn_size 
   This function encodes the size of the secret file extension into the least significant bits (LSB) of the image.
   It reads 32 bytes from the source image file, encodes the size of the extension using LSB encoding, and then writes the modified bytes to the stego image file.

  since size is an integer, it need 31 bytes to encode
  read 32 bits at a time from the source image and store inside the array
  call the function secret file extension size to lsb to encode the integer to the source image
  write it in the stego image file from the array 32 bytes at a time.

 */

Status encode_secret_file_extn_size(long extn_size, EncodeInfo *encInfo)
{
    char buffer[32];                                    

    fread(buffer, 32, 1, encInfo -> fptr_src_image); 

    encode_size_to_lsb(extn_size, buffer);      

    fwrite(buffer, 32, 1, encInfo -> fptr_stego_image);        

    return e_success;
}


/* Function: encode_secret_file_extn
  This function encodes the secret file extension into the least significant bits (LSB) of the image.
  For each character in the file extension, it reads 8 bytes from the source image, encodes the character using LSB encoding, and then writes the modified bytes to the stego image file.

  read 8bytes from source image and store it in the buffer
  since it is a character, call the byte to lsb function
  get 8byte from the buffer and write in the stego image file
  Returns:
    Status: e_success upon successful encoding, indicating the function executed successfully.
 */
 

Status encode_secret_file_extn(const char* file_extn, EncodeInfo *encInfo)
{
    char buffer[8];

    printf("\t\t\t:::extn = %s:::\n", file_extn);
    for(int i=0; i<strlen(file_extn); i++)
    {
        fread(buffer, 8, 1, encInfo -> fptr_src_image);        

        encode_byte_to_lsb(file_extn[i], buffer);              

        fwrite(buffer, 8, 1, encInfo -> fptr_stego_image);     
    }

    return e_success;
}


/* Fuction:Encode_secret_file_size

  This function encodes the size of the secret file into the least significant bits (LSB) of the image.
  It reads 32 bytes from the source image file, encodes the size using LSB encoding, and then writes the modified bytes to the stego image    file.
  Returns:
  Status: e_success upon successful encoding, indicating the function executed successfully.
 */
 

Status encode_secret_file_size(long file_size, EncodeInfo * encInfo)
{
    char buffer[32];

    fread(buffer, 32, 1, encInfo -> fptr_src_image);

    encode_size_to_lsb(file_size, buffer);

    fwrite(buffer, 32, 1, encInfo -> fptr_stego_image);

    return e_success;
}


/* Function:Encode_secret_file_data 

  This function encodes the actual data of the secret file into the LSB of the image.
  It reads the entire secret file into a buffer, and for each byte in the buffer, it reads 8 bytes from the source image,
  encodes the byte using LSB encoding, and then writes the modified bytes to the stego image file.

 */

Status encode_secret_file_data(EncodeInfo *encInfo)
{

    rewind(encInfo -> fptr_secret);

    char buffer[encInfo -> size_secret_file];

    char temp_buff[encInfo -> size_secret_file];

    fread(buffer, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);


    for(int i=0; i< encInfo -> size_secret_file; i++)
    {
        fread(temp_buff, 8, 1, encInfo -> fptr_src_image);

        encode_byte_to_lsb(buffer[i], temp_buff);

        fwrite(temp_buff, 8, 1, encInfo -> fptr_stego_image);
    }

    return e_success;
}


/* 
 Function:copy_remaining_img_data 

 Copy the remaining image bytes from the source image file to the stego image file after encoding have done.
 It reads one byte at a time from the source image file and writes it to the stego image file until the end of the source image file is      reached.
 Returns:
 e_success upon successful copying, indicating the function executed successfully.
  */

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;

    while((fread(&ch, 1, 1, fptr_src)) != 0)
    {
        fwrite(&ch, 1, 1, fptr_dest);
    }

    return e_success;
}
